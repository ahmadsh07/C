// 212478994 Ahmad Shamasnah
#ifndef UNTITLED1_GRADESOPERATIONS_H
#define UNTITLED1_GRADESOPERATIONS_H
#include "StudentList.h"
StudentList *FileToList();
void Report(StudentList*);
#endif
